package com.pms.authorization;

import static org.junit.Assert.assertEquals;

import org.junit.jupiter.api.Test;

class AuthorizationApplicationTests {

	@Test
	public void applicationContextLoaded() {
	}

	@Test
	public void isSwaggerEnabled() {
		AuthorizationApplication app=new AuthorizationApplication();
		assertEquals(true, app.swaggerConfiguration().isEnabled()); 
	}
}
