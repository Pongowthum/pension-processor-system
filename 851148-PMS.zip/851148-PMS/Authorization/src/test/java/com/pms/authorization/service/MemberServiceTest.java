package com.pms.authorization.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.pms.authorization.model.AuthenticationRequest;
import com.pms.authorization.repository.AuthenticationRepository;

public class MemberServiceTest {

	@Test
	public void memberServiceForValid() {
		AuthenticationRepository r = mock(AuthenticationRepository.class);
		AuthenticationRequest req = new AuthenticationRequest("admin", "admin");
		when(r.findByUsername("admin")).thenReturn(req);
		when(r.existsById("admin")).thenReturn(true);
		MemberService s = new MemberService(r);
		assertEquals("admin", s.getUserPassword("admin"));
	}

	@Test
	public void memberServiceForNotFound() {
		AuthenticationRepository r = mock(AuthenticationRepository.class);
		AuthenticationRequest req = new AuthenticationRequest("admin2", "admin2");
		when(r.findByUsername("admin")).thenReturn(req);
		when(r.existsById("admin")).thenReturn(false);
		MemberService s = new MemberService(r);
		assertNotEquals("admin", s.getUserPassword("admin2"));
	}

	@Test
	public void loadMemberTest() {
		MemberService service = mock(MemberService.class);
		assertEquals(0, service.loadMembers().size());
		List<AuthenticationRequest> value = new ArrayList<>();
		when(service.loadMembers()).thenReturn(value);
		assertEquals(0, service.loadMembers().size());
	}

}
