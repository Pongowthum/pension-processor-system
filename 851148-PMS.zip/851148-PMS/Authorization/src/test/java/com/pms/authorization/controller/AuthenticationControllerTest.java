package com.pms.authorization.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.ArrayList;

import org.junit.Test;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;

import com.pms.authorization.model.AuthenticationRequest;
import com.pms.authorization.service.MemberService;
import com.pms.authorization.util.JwtUtil;

public class AuthenticationControllerTest {

	@Test
	public void createAuthenticationTokenIfValid() throws Exception {
		AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
		MemberService memberService = mock(MemberService.class);
		JwtUtil jwtUtil = mock(JwtUtil.class);
		AuthenticationController controller = new AuthenticationController(authenticationManager, memberService,
				jwtUtil);
		when(memberService.loadUserByUsername("admin")).thenReturn(new User("admin", "admin", new ArrayList<>()));
		final UserDetails userDetails = memberService.loadUserByUsername("admin");
		when(jwtUtil.generateToken(userDetails)).thenReturn("jwt123");
		assertEquals(HttpStatus.OK,
				controller.createAuthenticationToken(new AuthenticationRequest("admin", "admin")).getStatusCode());
	}

	@Test
	public void createAuthenticationTokenIfInValid() throws Exception {
		AuthenticationManager authenticationManager = mock(AuthenticationManager.class);
		MemberService memberService = mock(MemberService.class);
		JwtUtil jwtUtil = mock(JwtUtil.class);
		AuthenticationController controller = new AuthenticationController(authenticationManager, memberService,
				jwtUtil);
		when(authenticationManager
				.authenticate(new UsernamePasswordAuthenticationToken("admin", "admi", new ArrayList<>())))
						.thenThrow(new BadCredentialsException(""));
		assertEquals(HttpStatus.OK,
				controller.createAuthenticationToken(new AuthenticationRequest("admin", "admi")).getStatusCode());
	}
}
