package com.pms.authorization.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pms.authorization.model.AuthenticationRequest;
import com.pms.authorization.model.AuthenticationResponse;
import com.pms.authorization.service.MemberService;
import com.pms.authorization.util.JwtUtil;

import io.swagger.annotations.ApiOperation;

@RestController
public class AuthenticationController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private MemberService memberService;

	@Autowired
	private JwtUtil jwtUtil;
	

	public AuthenticationController(AuthenticationManager authenticationManager, MemberService memberService,
			JwtUtil jwtUtil) {
		this.authenticationManager = authenticationManager;
		this.memberService = memberService;
		this.jwtUtil = jwtUtil;
	}


	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(value = "/authenticate", method = RequestMethod.POST)
	@ApiOperation(value="Send JWT to client",notes="It takes username and password as input and return JWT token if the credintials are correct")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest)
			throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword()));
		} 
		catch (BadCredentialsException e) 
		{
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		final UserDetails userDetails = memberService.loadUserByUsername(authenticationRequest.getUsername());
		final String jwt = jwtUtil.generateToken(userDetails);
		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	}

}
