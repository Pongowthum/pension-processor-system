package com.pms.pensionerdetail.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import com.pms.pensionerdetail.model.PensionerDetail;
import com.pms.pensionerdetail.repository.PensionerRepository;

public class LoadPensionerServiceTest {

	@Autowired
	MockMvc mockMvc;

	@MockBean
	private static PensionerRepository repository;

	@Test
	public void GetPensionerDetailByAadhar_IfValid() throws Exception {
		PensionerDetail detail = new PensionerDetail("1", "Nabeel", "03-12-1999", "100", 29000, 1200, "self", "SBI",
				"1000", "private");
		PensionerRepository r = mock(PensionerRepository.class);
		when(r.findByAadharId("1")).thenReturn(detail);
		when(r.existsById("1")).thenReturn(true);
		LoadPensionerService s = new LoadPensionerService(r);
		assertEquals("1", s.getPensionerDetailByAadhar("1").getAadharId());
	}

	@Test(expected = NullPointerException.class)
	public void GetPensionerDetailByAadhar_IfNotValid() throws Exception {
		PensionerDetail detail = new PensionerDetail("1", "Nabeel", "03-12-1999", "100", 29000, 1200, "self", "SBI",
				"1000", "private");
		PensionerRepository r = mock(PensionerRepository.class);
		when(r.findByAadharId("1")).thenReturn(detail);
		when(r.existsById("1")).thenReturn(false);
		LoadPensionerService s = new LoadPensionerService(r);
		assertEquals(null, s.getPensionerDetailByAadhar("1").getAadharId());
	}

}
