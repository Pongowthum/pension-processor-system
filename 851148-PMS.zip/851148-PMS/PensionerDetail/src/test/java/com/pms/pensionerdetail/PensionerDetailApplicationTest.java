package com.pms.pensionerdetail;

import static org.junit.Assert.*;

import org.junit.Test;

public class PensionerDetailApplicationTest {

	@Test
	public void isSwaggerEnabled() {
		PensionerDetailApplication app = new PensionerDetailApplication();
		assertEquals(true, app.swaggerConfiguration().isEnabled());
	}

	@Test
	public void mainTest() {
		PensionerDetailApplication.main(new String[] {});
	}

}
