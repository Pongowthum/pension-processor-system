package com.pms.pensionerdetail.service;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.stereotype.Service;

@Service
public class MyUserDetailsServiceTest {

	@Test
	public void getUserPasswordIfCorrect() {
		assertEquals("admin", MyUserDetailsService.getUserPassword("admin"));
	}

	@Test
	public void getUserPasswordIfIncorrect() {
		assertEquals("Not Found", MyUserDetailsService.getUserPassword("admi"));
	}

}