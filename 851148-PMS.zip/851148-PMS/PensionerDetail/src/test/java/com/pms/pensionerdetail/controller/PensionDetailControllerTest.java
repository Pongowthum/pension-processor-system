package com.pms.pensionerdetail.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;

import com.pms.pensionerdetail.model.PensionerDetail;
import com.pms.pensionerdetail.security.JwtUtil;
import com.pms.pensionerdetail.service.LoadPensionerService;

public class PensionDetailControllerTest {
	


	@Test
	public void ifValid() throws Exception {		
		
		HttpServletRequest request=mock(HttpServletRequest.class);
		PensionerDetail detail=new PensionerDetail("471032686624", "Pongowthum", "17-06-1999", "FLRPP3466C", 80000, 5000, "self", "ICICI", "423802000000", "private");
		LoadPensionerService service=mock(LoadPensionerService.class);
		JwtUtil jwtUtil=mock(JwtUtil.class);
		
		when(request.getHeader("Authorization")).thenReturn("Bearer token");
		when(jwtUtil.validateToken("token")).thenReturn(true);
		when(service.getPensionerDetailByAadhar("471032686624")).thenReturn(detail);	
		
		PensionDetailController controller=new PensionDetailController();
		controller.getPensionerDetailByAadhar("471032686624", request);		
	}

}
