package com.pms.pensionerdetail.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.pms.pensionerdetail.model.PensionerDetail;
import com.pms.pensionerdetail.security.JwtUtil;
import com.pms.pensionerdetail.service.LoadPensionerService;

import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.SignatureException;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@CrossOrigin(origins = "*")
class PensionDetailController {

	@Autowired
	private LoadPensionerService service;

	@Autowired
	private JwtUtil jwtUtil;

	public PensionDetailController(LoadPensionerService service, JwtUtil jwtUtil) {
		this.service = service;
		this.jwtUtil = jwtUtil;
	}

	PensionDetailController() {
	}

	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/PensionerDetailByAadhaar/{aadharId}", method = RequestMethod.GET)
	@ApiOperation(value = "Get Pensioner By Aadhar", notes = "It takes Aadhar number as input and return Pensioner details if the aadhar number and autherization is valid")
	public ResponseEntity<?> getPensionerDetailByAadhar(
			@ApiParam(value = "Unqiue identification key to retrive pensioner", required = true) @PathVariable("aadharId") String aadharId,
			HttpServletRequest request) {

		try {
			final String authorizationHeader = request.getHeader("Authorization");
			String token = authorizationHeader.substring(7);

			if (jwtUtil.validateToken(token)) {
				PensionerDetail detail = service.getPensionerDetailByAadhar(aadharId);
				if (detail != null) {
					log.debug("Successfully provided details for " + aadharId);
					return ResponseEntity.ok(detail);
				}
				log.info("No data available for " + aadharId);
				return new ResponseEntity<Object>(HttpStatus.NOT_FOUND);
			} else {
				log.info("Invalid token " + aadharId);
				return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
			}
		} catch (NullPointerException e) {
			log.info("No valid token provided");
			return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
		} catch (SignatureException e) {
			log.info("Invalid token");
			return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
		} catch (MalformedJwtException e) {
			log.info("Manipulated token rejected");
			return new ResponseEntity<Object>(HttpStatus.FORBIDDEN);
		}
	}
}