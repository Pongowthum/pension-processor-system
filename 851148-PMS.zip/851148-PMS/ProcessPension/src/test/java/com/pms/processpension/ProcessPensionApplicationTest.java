package com.pms.processpension;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
import org.springframework.web.client.RestTemplate;

public class ProcessPensionApplicationTest {

	@Test
	public void isRestTemplateInstantiated() {
		ProcessPensionApplication app=new ProcessPensionApplication();
		assertEquals(RestTemplate.class, app.getRestTemplate().getClass());
	}
	
	@Test
	public void isSwaggerEnabled() {
		ProcessPensionApplication app=new ProcessPensionApplication();
		assertEquals(true, app.swaggerConfiguration().isEnabled()); 
	}
	
	@Test
	   public void main() {
		ProcessPensionApplication.main(new String[] {});
	   }

}
