package com.pms.processpension.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;

import org.junit.Test;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import com.pms.processpension.model.PensionerDetail;
import com.pms.processpension.model.ProcessPensionInput;
import com.pms.processpension.repository.PensionRepository;
import com.pms.processpension.security.JwtUtil;

public class ProcessPensionTest<T> {

	@Test
	public void test() throws Exception {

		HttpServletRequest request = mock(HttpServletRequest.class);

		RestTemplate restTemplate = mock(RestTemplate.class);
		PensionRepository repository = mock(PensionRepository.class);
		JwtUtil jwtUtil = mock(JwtUtil.class);
		ProcessPensionInput processPensionInput = mock(ProcessPensionInput.class);
		ProcessPensionController controller = new ProcessPensionController(restTemplate, repository, jwtUtil);
		 @SuppressWarnings("rawtypes")
		ResponseEntity exchange = mock(ResponseEntity.class);
		
		when(request.getHeader("Authorization")).thenReturn("Bearer token");
		when(processPensionInput.getAadharId()).thenReturn("471032686624");
		when(jwtUtil.validateToken("token")).thenReturn(true);
		

		PensionerDetail detail = new PensionerDetail();
		HttpHeaders headers = new HttpHeaders();
		headers.set("Authorization", "Bearer " + "token");
		
		HttpEntity<PensionerDetail> requestEntity = new HttpEntity<>(detail, headers);

		PensionerDetail value = new PensionerDetail("471032686624", "Nabeel", "03-12-1999", "100", 29000, 1200, "self", "SBI",
				"1000", "private");
		when(restTemplate.exchange("http://pensioner-detail-service/PensionerDetailByAadhaar/471032686624", HttpMethod.GET,
				requestEntity, PensionerDetail.class)).thenCallRealMethod().thenReturn(ResponseEntity.ok(value));
		
		when(exchange.getBody()).thenReturn(value);
		controller.processPentionByAadhar(processPensionInput, request);

	}

	@Test
	public void IfInvalidToken() {

		HttpServletRequest request = mock(HttpServletRequest.class);

		RestTemplate restTemplate = mock(RestTemplate.class);
		PensionRepository repository = mock(PensionRepository.class);
		JwtUtil jwtUtil = mock(JwtUtil.class);
		ProcessPensionInput processPensionInput = mock(ProcessPensionInput.class);
		ProcessPensionController controller = new ProcessPensionController(restTemplate, repository, jwtUtil);

		when(request.getHeader("Authorization")).thenReturn("Bearer token");
		when(processPensionInput.getAadharId()).thenReturn("471032686624");
		when(jwtUtil.validateToken("token")).thenReturn(false);

		controller.processPentionByAadhar(processPensionInput, request);

		assertEquals(403, controller.processPentionByAadhar(processPensionInput, request).getStatusCodeValue());

	}
}
