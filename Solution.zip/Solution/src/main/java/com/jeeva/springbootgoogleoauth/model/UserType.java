package com.jeeva.springbootgoogleoauth.model;

public enum UserType {

    google,devglan
}
