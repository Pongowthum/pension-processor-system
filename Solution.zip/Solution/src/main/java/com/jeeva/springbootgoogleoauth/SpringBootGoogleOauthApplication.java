package com.jeeva.springbootgoogleoauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGoogleOauthApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGoogleOauthApplication.class, args);
	}

}

