package com.jeeva.springbootgoogleoauth.service;

import com.jeeva.springbootgoogleoauth.model.User;

public interface UserService {
    String signUp(User user);
}
